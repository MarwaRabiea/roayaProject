const User = require("../model/user");
const express = require("express");
const asyncHandler = require("express-async-handler");
const bcrypt = require("bcrypt");
const { check, validationResult } = require("express-validator");
const jwt = require("jsonwebtoken");
const JWT_SECRET_KEY = process.env.JWT_SECRET_KEY;

const bookRouter = express.Router();

bookRouter.post(
  "/",
  asyncHandler(async (req, res) => {
    const token = req.headers["x-token"];
    const user = await jwt.verify(token, JWT_SECRET_KEY);

    if (user.role !== "admin") {
      return res
        .status(401)
        .json({ message: "Unauthorized: alloew only for admins" });
    }

    const { name } = req.body;

    return res.json(name);
  })
);

module.exports = bookRouter;
