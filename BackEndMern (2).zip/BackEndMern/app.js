const express =require("express");

const cors = require("cors")
const mongoose =require("mongoose")

const mongouri = "mongodb://localhost:27017/MernBack"

const app =express();
app.use(express.json())
app.use(express.urlencoded({extended: false}))

mongoose.set("strictQuery", false)
mongoose.connect('mongodb://127.0.0.1:27017/MernBack')
.then( () => console.log("Database connected"));


app.use('/', require('./routes/authRoutes'));

const port=8000;
app.listen(port, () => console.log("server runnimg in port 8000"));