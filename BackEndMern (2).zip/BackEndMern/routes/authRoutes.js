const express = require("express");
const router = express.Router();
const cors = require("cors")
const { test, registerUser,loginUser } = require('../controllers/authControllers')
router.use(
    cors({
        credentials: true,

    }
    )
)

router.get('/', test)
router.post('/register', registerUser)
router.post('/login' ,loginUser)

module.exports = router 